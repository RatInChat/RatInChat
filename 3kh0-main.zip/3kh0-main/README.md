<img alt="IF YOU ARE VIEWING THIS PAGE FROM SEARCH, THIS IS NOT MY ACTUAL WEBSITE! GO TO 3kh0.github.io FOR GAMES AND STUFF!" src="https://readme-typing-svg.herokuapp.com?vCenter=true&lines=Hello!+I+am+Echo!;HTML+Coder;JavaScript+Game+maker;Talk+to+me+on+my+discord!">
<h1 align="center">Hi 👋, I'm 3kh0</h1>
<h3 align="center">A nice person who can code buggy projects.</h3>
<h2>Programmer Humor</h2>
<img src="https://readme-jokes.vercel.app/api" alt="Jokes Card" />
<h2>About me</h2>
<p align="left"> 
  <img src="https://komarev.com/ghpvc/?username=3kh0&label=Profile Visitors&color=001eff&style=flat" alt="3kh0" /> 
  <img src="https://img.shields.io/badge/OS-macOS-lightgrey/?logo=apple" alt="os">
  <img src="https://img.shields.io/badge/Editor-VS%20Code-blue/?logo=visualstudiocode&logoColor=blue&color=blue" alt="editor">
  <img src="https://img.shields.io/badge/Editor-Sublime%20Text-blue/?logo=sublimetext&logoColor=warning&color=orange" alt="editor2">
  <img src="https://img.shields.io/reddit/user-karma/combined/3kh0_reddit?logo=reddit" alt="Reddit User Karma">
  <img src="https://img.shields.io/badge/Listens%20to-Spotify-blue/?logo=spotify&logoColor=warning&color=1DB954" alt="music">
  <img src="https://img.shields.io/badge/Knows-JavaScript-blue/?logo=javascript&logoColor=warning&color=yellow" alt="js">
  <img src="https://img.shields.io/badge/Knows-HTML-blue/?logo=html5&logoColor=warning&color=orange" alt="html">
  <img src="https://img.shields.io/badge/Knows-MarkDown-FFF?logo=markdown" alt="markdown">
  <img src="https://img.shields.io/badge/Uses-stackoverflow-blue/?logo=stackoverflow&logoColor=warning&color=ef8236" alt="stack">
  <img alt="gmail" src="https://img.shields.io/badge/Uses-Gmail-blue/?logo=gmail&logoColor=warning&color=red">
  <img alt="opera" src="https://img.shields.io/badge/Uses-OperaGX-blue/?logo=opera&logoColor=ff1b2d&color=ff1b2d">
  <img alt="steam" src="https://img.shields.io/badge/Uses-Steam-blue/?logo=steam&logoColor=1b2838&color=1b2838">
  <img src="https://img.shields.io/badge/Uses-Discord-blue/?logo=discord&logoColor=warning&color=7289DA" alt="discord">
  <img alt="GitHub Sponsors" src="https://img.shields.io/github/sponsors/3kh0?label=Sponsors&logo=githubsponsors&style=flat">
  <img alt="GitHub User's stars" src="https://img.shields.io/github/stars/3kh0?color=yellow&label=User%20Stars&logo=github&logoColor=yellow">
  <img alt="GitHub followers" src="https://img.shields.io/github/followers/3kh0?color=g&label=User%20Followers&logo=github">
       </p>
<p align="left"> <a href="https://github.com/ryo-ma/github-profile-trophy"><img src="https://github-profile-trophy.vercel.app/?username=3kh0&theme=discord" alt="3kh0" /></a> </p>

- 🔭 I’m currently working on [my main website](https://github.com/3kh0/3kh0.github.io).

- 🌱 I’m currently learning [Python](https://www.google.com/books/edition/Python_All_in_One_For_Dummies/A0QlEAAAQBAJ?hl=en&gbpv=0).

- 👯 I’m looking to collaborate on [making my website better](https://github.com/3kh0/3kh0.github.io).

- 🤝 I’m looking for help with [CSS](https://github.com/3kh0/3kh0.github.io/projects/1).

- 👨‍💻 All of my projects are available at [https://3kh0.github.io/](https://3kh0.github.io/).

- 📫 How to reach me [my epic discord server](https://discord.gg/44yAbMWbHb).

- ⚡ Fun fact [I have a pretty cool website](https://3kh0.github.io)!

<h3 align="left">Connect with me</h3>
<p align="left">
<a href="https://twitter.com/3kh0_" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/twitter.svg" alt="3kh0_" height="30" width="40" /></a>
<a href="https://discord.gg/44yAbMWbHb" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/discord.svg" alt="44yAbMWbHb" height="30" width="40" /></a>
</p>
<p align="left"> <a href="https://twitter.com/3kh0_" target="blank"><img src="https://img.shields.io/twitter/follow/3kh0_?logo=twitter&style=for-the-badge" alt="3kh0_" /></a> <br>
<a href="https://discord.gg/44yAbMWbHb" target="blank"><img align="center" src="https://img.shields.io/discord/840084542332076102?label=Server&logo=discord&logoColor=white&style=for-the-badge" alt="discord"></a></p>


<h2 align="left">Stats</h2>

<p><img  src="https://github-readme-stats.vercel.app/api/top-langs?username=3kh0&show_icons=true&theme=dark&locale=en&langs_count=10&layout=compact" alt="3kh0" /></p>
<p>&nbsp;<img src="https://github-readme-stats.vercel.app/api?username=3kh0&show_icons=true&theme=dark&locale=en" alt="3kh0" /></p>
<p><img src="https://github-readme-streak-stats.herokuapp.com/?user=3kh0&theme=dark" alt="3kh0" /></p><br>
  </html>

## Spotify:

[![spotify-github-profile](https://spotify-github-profile.vercel.app/api/view?uid=z3dlpi0cfntezy77ypqi8xass&cover_image=true&theme=default)](https://spotify-github-profile.vercel.app/api/view?uid=z3dlpi0cfntezy77ypqi8xass&redirect=true)


## Other stuff: <br>

<table><tbody><tr><td><a href="https://octo-ring.com/"><img src="https://octo-ring.com/static/img/widget/top.png" width="99%" alt="Octo Ring logo" align="top"></a><br><a href="https://octo-ring.com/p/3kh0/prev"><img src="https://octo-ring.com/static/img/widget/prev.png" width="33%" alt="previous" align="top" title="previous profile"></a><a href="https://octo-ring.com/p/3kh0/random"><img src="https://octo-ring.com/static/img/widget/random.png" width="33%" alt="random" align="top" title="random profile"></a><a href="https://octo-ring.com/p/3kh0/next"><img src="https://octo-ring.com/static/img/widget/next.png" width="33%" alt="next" align="top" title="next profile"></a><br><a href="https://octo-ring.com/"><img src="https://octo-ring.com/static/img/widget/bottom.png" width="99%" alt="check out other GitHub profiles in the Octo Ring" align="top"></a></td></tr></tbody></table>

<a href="https://octoprofile.vercel.app/user?id=3kh0">Octoprofile</a>
</html>

Also for those who wanted the dragon here:

![Cool dragon](https://3kh0.github.io/img/drag.png)
